﻿using System;
using System.Net.Sockets;
namespace SoketDemo
{
  class Program
  {
    // 设置连接端口
    const int portNo = 7777;
    static void Main(string[] args)
    {
      // 初始化服务器IP
      System.Net.IPAddress localAdd = System.Net.IPAddress.Parse("127.0.0.1");
      // 创建TCP侦听器
      TcpListener listener = new TcpListener(localAdd, portNo);
      listener.Start();
      // 显示服务器启动信息
      Console.WriteLine("服务器开启..."+DateTime.Now.ToString());
      // 循环接受客户端的连接请求
      while (true)
      {
        ChatClient user = new ChatClient(listener.AcceptTcpClient());
        // 显示连接客户端的IP与端口
        Console.WriteLine(user._clientIP + " 加入" + DateTime.Now.ToString());
      }
    }
  }
}